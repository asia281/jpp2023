# Testy

### Użycie

```sh
git clone git@gitlab.com:mimuw-rocznik-2001/jpp-2023/testy-zad3.git
# alternatywnie:
# git clone https://gitlab.com/mimuw-rocznik-2001/jpp-2023/testy-zad3.git

ln -s "$PWD/ab123456.pl" "$PWD/testy-zad3/solution.pl"
cd testy-zad3

./test.sh
```

### Docs

Przypominam, by nie zadawać pytań na forum jak nie trzeba. 
Istnieje docs z listą pytań i odpowiedzi.
Link do niego jest gdzieś na grupie fb.

### Dodawanie swoich testów

Patrz [tutaj](https://gitlab.com/mimuw-ipp-2021/testy-duze-zadanie-3)
