Wiadomo, że plik z trasami zawiera "stałe".
Definicja stałej w Prologu 
[stąd](https://www.dai.ed.ac.uk/groups/ssp/bookpages/quickprolog/node5.html)
zakłada, że stała to liczba lub atom,
zaś atom to string, nazwa, ciąg pewnych znaczków lub pewne specyficzne znaczki.
