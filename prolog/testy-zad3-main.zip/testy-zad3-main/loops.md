Z treści nie wynika czy są dozwolone pętelki.
Wiadomo tylko, że "można założyć całkowitą poprawność danych w pliku",
ale nie wiadomo dokładniej co to oznacza.
Prawdopodobnie pętelki nie są dozwolone,
ale jeżeli były, proponuję je traktować jak zwykłe krawędzie.

Ten test zakłada, że każdą pętelkę można przejść na dwa sposoby
(tak jak pieszy może okrążyć rondo zgodnie lub przeciwnie do wskazówek zegara).
