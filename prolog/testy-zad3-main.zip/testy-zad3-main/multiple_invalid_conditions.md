W treści nie jest sprecyzowane 
czy mamy wypisać wszystkie niepasujące warunki,
czy tylko pierwszy niepasujący.
Z tego powodu z dużym prawdopodobieństwem można
uznać, że nie będzie to testowane.
Ale lepiej jest, żeby wszyscy mieli tak samo,
więc ja proponuję wypisywać wszystkie
(co się wydaje "poprawniejsze" od wypisywania jednego,
więc gdyby to jednak było testowane,
to jest łatwiej uzasadnić, że tak powinno być).
